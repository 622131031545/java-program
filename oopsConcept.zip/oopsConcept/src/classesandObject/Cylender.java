package classesandObject;

import inheritance.Shape1;

public class Cylender extends Shape1 {

	public Cylender(int radius) {
		super(radius);
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
