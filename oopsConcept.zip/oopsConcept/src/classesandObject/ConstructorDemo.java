package classesandObject;

public class ConstructorDemo {
    public  ConstructorDemo() {
    	 System.out.println("Constructor Called");
     }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ConstructorDemo cd=new ConstructorDemo();
        AccessSpecifiers as=new AccessSpecifiers();
        as.num1=20; 
       // as.num2=30; not allowed as it is private dm
        as.num3=40;
	}

}
