package classesandObject;

public class Student {
	int rno;
	String name;
	float percentage;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student();
		s1.rno=1;
		s1.name="shaibaj";
		s1.percentage=75.2f;
		
		System.out.println("Student Details\n Roll number:"
				+ ""+s1.rno+"\nName :"+s1.name+"\npercentage:"+s1.percentage);

	}

}
