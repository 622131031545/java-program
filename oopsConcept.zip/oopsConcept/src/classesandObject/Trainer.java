package classesandObject;

public class Trainer {
    int trno;
    String tName;
    String tsub;
   double tfees;
   int time_start;
   int time_end;
   
   
    
    
	public void Trainer(int trno, String tName, String tsub, double tfees, int time_start, int time_end) {
	
	this.trno = trno;
	this.tName = tName;
	this.tsub = tsub;
	this.tfees = tfees;
	this.time_start = time_start;
	this.time_end = time_end;
}




	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trainer t=new Trainer();
	
			t.Trainer(1,"pankaj sir","java",8000,7,10);
			System.out.println("Trainer Detailes are");
			System.out.println("Number is:"+t.trno);
			System.out.println("Name is:"+t.tName);
			System.out.println("subject teaching :"+t.tsub);
			System.out.println("Fees :"+t.tfees);
			System.out.println("Time start: "+t.time_start);
			System.out.println("Time End : "+t.time_end);
		
	}

}
