package classesandObject;

class Demo{
	void demo() {
		AccessSpecifiers as=new AccessSpecifiers();
		as.num1=20;
	//	as.num2=20; not allowed as it is private dm
		as.num3=30;
	}
}
public class AccessSpecifiers {

	int num1;  // data member with defualt specifier
	private int num2;
	public int num3;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccessSpecifiers as=new AccessSpecifiers();
		as.num1=10;
		as.num2=20;
		as.num3=40;
	}

}
