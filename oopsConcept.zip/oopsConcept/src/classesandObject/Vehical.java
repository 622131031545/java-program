package classesandObject;

public class Vehical {
	int numOfWheels;
	String brandName;
	String companyName;
	String color;
	double price;
	
	 void Vehical(int numOfWheels, String brandName, String companyName, String color, int price )
    {
	this.numOfWheels=numOfWheels;
		this.brandName=brandName;
		this.companyName=companyName;
		this.color=color;
		this.price=price;
    	
    }
	
	
void bike()
{
	System.out.println("Vehical Details are");
	System.out.println("Number of Wheels :"+numOfWheels);
	System.out.println("Brand Name :"+brandName);
	System.out.println("Company Name"+companyName);
	System.out.println("Color :"+color);
	System.out.println("price :"+price);
		
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehical v=new Vehical();
		v.Vehical(2,"Bike","Honda","red",90000);
		
		v.bike();
		
	
	/*	v.numOfWheels=2;
		v.brandName="Bike";
		v.companyName="honda";
		v.color="black";
		v.price=92000;
		System.out.println("Vehical Details are\nNumber of Wheels :"+numOfWheels);
		*/
		
	}

}
