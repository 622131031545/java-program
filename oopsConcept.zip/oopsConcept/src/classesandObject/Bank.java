package classesandObject;

public class Bank {

	String bankName;
	String address;
	
	//defualt constructor
	public Bank() {
		this.bankName="RBI";
		this.address="Mumbai";
 	}
	
	//Parameterised Constructor
	public Bank(String bankName,String address) {
		this.bankName=bankName;
		this.address=address;
		
	}
	
	void bankDetails() {
		System.out.println("Bank Name "+this.bankName+"\nBank Address"+this.address);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Bank b1=new Bank();
         Bank b2=new Bank("SBI","Pune");
         
         b1.bankDetails();
         b2.bankDetails();
	}

}
