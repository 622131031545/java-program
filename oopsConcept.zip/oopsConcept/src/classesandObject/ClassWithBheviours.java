package classesandObject;

class Student1{
	int rno;
	String name;
	float percentage;
	
	void setDetails(int rollno,String name,float percentage) {
		rno=rollno;
		this.name=name;
		this.percentage=percentage;
	}
	void showDetails() {
		System.out.println("Student Details\nRoll Number"+this.rno+"\nName "+this.name+"\nPercentage "+this.percentage);
	}
}
public class ClassWithBheviours {

	public static void main(String[] args) {
		Student1 s1=new Student1();
		s1.setDetails(1, "Aniket", 70.89f);
		
		Student1 s2=new Student1();
		s2.setDetails(2, "Anjali", 60.54f);
		
		s1.showDetails();
		s2.showDetails();

	}

}
