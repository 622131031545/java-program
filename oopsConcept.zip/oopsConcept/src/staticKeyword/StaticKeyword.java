package staticKeyword;

import java.util.Scanner;

public class StaticKeyword {
	static  String instituteName;
    static
	{
    	//instituteName="Exucia";
    	
		System.out.println("Trying to execute before main method");
		System.out.println("Enter institute name");
		Scanner sc=new Scanner(System.in); 
		instituteName=sc.nextLine();
	}
	/*static String instituteName;
	       int number;
	static void show() {
		instituteName="Exucia pvt ltd";
		System.out.println("Static variable value "+instituteName);
		// number=23;   not allowd as instance variable are object dependent
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/* instituteName="Exucia";
      System.out.println("Satic variable value "+instituteName);
      instituteName="Exucia pvt ltd";
      System.out.println("Satic variable value "+instituteName);*/
	/*	instituteName="Exucia";
		show();*/ 
		
		System.out.println("Main method started it's execution");
		System.out.println("Static variable value "+instituteName);
	}

}
