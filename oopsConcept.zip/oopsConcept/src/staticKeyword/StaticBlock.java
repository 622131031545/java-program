package staticKeyword;

public class StaticBlock {

	static {
		System.out.println("Static Block");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Main method");
	System.out.println("Static variable value "+StaticKeyword.instituteName);
		
	}
}
