package abstraction;
/**create abstract class shape with abstract method getArea()
 *  and provide the implementation within squares and rectangle class*****/
abstract class Shape {
   
    abstract float getArea();
}
class Square extends Shape {
  
     float s;

   
    public Square(float s) {
        this.s = s;
    }
    @Override
    float getArea() {
        return s * s;
    }
}

class Rectangle extends Shape {
    
     float length;
     float width;

   
    public Rectangle(float length, float width) {
        this.length = length;
        this.width = width;
    }

   
    @Override
    float getArea() {
        return length * width;
    }
}
public class AbstractClass {
	public static void main(String[] args) {
	Square s = new Square(5);
    System.out.println("Area of Square: " + s.getArea());   
    Rectangle r = new Rectangle(3, 4);
    System.out.println("Area of Rectangle: " + r.getArea());
}
}