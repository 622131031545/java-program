package abstraction;

abstract class ClassWithDM{
	public int number;
	final public int num1=14;
	static int num2;
}

public class DMInAbstractClass extends ClassWithDM{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DMInAbstractClass obj=new DMInAbstractClass();
		obj.number=12;
		System.out.println(obj.num1);
		System.out.println(num2);
	}

}
