package abstraction;

public class AbstractClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractChild ac=new AbstractChild();
		ac.call();
		ac.show();
		ac.call1();
		ac.call2();
	/*	AbstractParent ap=new AbstractParent(); parent class does not create object*/
	}

}
