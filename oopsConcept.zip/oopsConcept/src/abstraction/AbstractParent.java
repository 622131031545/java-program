package abstraction;

 abstract class AbstractParent {
abstract public void show() ;
public void call()
{
	System.out.println("non abstract Method.........");
}
public final void call1()
{
	System.out.println("non abstract Method final.........");
}
public void call2()
{
	System.out.println("non abstract Method static.........");
}
}
 class AbstractChild extends AbstractParent{
	 public void show() {
			System.out.println("Abstract Method is implemented");
		}
	 }
