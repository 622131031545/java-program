package abstraction;

abstract class staticAbstarctParent{
	 
	 static void call() {
		
	}
	// abstract static public void  show(); abstarct method can not be static
	// final abstract void callMe();  abstarct method can not be final
}
public class StaticMethodInAbstractClass {

	public static void main(String[] args) {
		

	}

}
