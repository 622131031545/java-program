package inheritanceAssignment;


class Employee1 extends Person {
    private int id;
    private double hourlyPay;

    public Employee1(String lastName, int id, double hourlyPay) {
        super(lastName);
        this.id = id;
        this.hourlyPay = hourlyPay;
    }

    public int getId() {
        return id;
    }

    public double getHourlyPay() {
        return hourlyPay;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setHourlyPay(double hourlyPay) {
        this.hourlyPay = hourlyPay;
    }

    public double getRaise() {
        double raiseAmount = hourlyPay * 0.15;
        hourlyPay += raiseAmount;
        return hourlyPay;
    }

    public double payDay(int hoursWorked) {
        double totalPay;
        if (hoursWorked > 40) {
            totalPay = (40 * hourlyPay) + ((hoursWorked - 40) * hourlyPay * 1.5);
        } else {
            totalPay = hoursWorked * hourlyPay;
        }
        return totalPay;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Employee)) {
            return false;
        }
        Employee1 emp = (Employee1) obj;
        return (this.id == emp.id) && (this.getLastName()==(emp.getLastName()));
    }
}