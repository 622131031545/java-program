package inheritanceAssignment;
/*7. Write the below code
Step 1
You will be completing a class named Employee that will inherit from the class Person.

Finish the extends statement in the Employee class header
Write the Employee constructor don’t forget your call to super
Create two private class variables: an int id, and a double hourlyPay
Since they are both private variables, write getters and setters for both variables: getId, getHourlyPay, setId, setHourlyPay

Step 2
In the Employee class, complete the getRaise method. This method gives a raise to the user, increasing their total hourly pay by 15%. This method also updates the hourly pay class variable you made as well. Finally return the value of the employee’s new hourlyPay.

Step 3
Inside the Employee class complete the method payDay. This method calculates how much the employee earned for the week. First calculate their pay, if the employee worked more than 40 hours, then any hour OVER 40 is worth 1.5 times their normal pay, this is considered overtime pay, otherwise their pay is as normal. Return their total pay for the week.

Example: if I worked 45 hours this week, I would get 5 hours of overtime pay and 40 hours of normal pay.

Step 4
Inside the Employee class, we will now override the equals method.

The method will return true if the employees share the same ID AND their last names are the same Otherwise, the two are not the same and the method will return false.
*/
public class A7 {


    public static void main(String[] args) {
       
        Employee1 emp1 = new Employee1("Shaibaj", 1, 15.0);
        Employee1 emp2 = new Employee1("Pranav", 2, 20.0);

        
        emp1.setId(101);
        emp2.setHourlyPay(25.0);

        
        System.out.println("Employee 1:");
        System.out.println("Last Name: " + emp1.getLastName());
        System.out.println("ID: " + emp1.getId());
        System.out.println("Hourly Pay: $" + emp1.getHourlyPay());
        System.out.println();

        System.out.println("Employee 2:");
        System.out.println("Last Name: " + emp2.getLastName());
        System.out.println("ID: " + emp2.getId());
        System.out.println("Hourly Pay: $" + emp2.getHourlyPay());
        System.out.println();

       
        System.out.println("Employee 1's New Hourly Pay After Raise: $" + emp1.getRaise());
        System.out.println();

       
        int hoursWorked = 45;
        System.out.println("Employee 2's Total Pay for the Week: $" + emp2.payDay(hoursWorked));
        System.out.println();

        // Testing equals method
        Employee1 emp3 = new Employee1("Sagar", 1, 15.0); // Same as emp1
        System.out.println("Are Employee 1 and Employee 3 the same? " + emp1.equals(emp3));
    }
}
