package inheritanceAssignment;

public class A5 {
	 public static void main(String[] args) {
	        Circle5 c = new Circle5(5);
	        System.out.println("Circle radius: " + c.getRadius());
	        System.out.println("Circle area: " + c.area());
	        System.out.println("Circle circumference: " + c.circumference());

	        System.out.println();

	        Cylinder cy = new Cylinder(5, 10);
	        System.out.println("Cylinder radius: " + cy.getRadius());
	        System.out.println("Cylinder height: " + cy.getHeight());
	        System.out.println("Cylinder volume: " + cy.volume());
	        System.out.println("Cylinder surface area: " + cy.surfaceArea());
	    }
}
