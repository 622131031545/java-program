package inheritanceAssignment;
/*2.Create a class named 'Member' having the following members:
Data members
1 - Name
2 - Age
3 - Phone number
4 - Address
5 - Salary
It also has a method named 'printSalary' which prints the salary of the members.
Two classes 'Employee' and 'Manager' inherits the 'Member' class.
 The 'Employee' and 'Manager' classes have data members 'specialization' and 'department' 
respectively. Now, assign name, age, phone number, address and salary to an employee and
 a manager by making an object of both of these classes and print the same.
*/
class Member {
 
 String name;
 int age;
 String phoneNumber;
 String address;
 double salary;

 public void printSalary() {
     System.out.println("Salary: " + salary);
 }
}

class Employee extends Member {

 String specialization;
}

class Manager extends Member {

 String department;
}

public class A2 {

	public static void main(String[] args) {
	     
	     Employee emp = new Employee();
	     Manager m = new Manager();

	     emp.name = "Shaibaj";
	     emp.age = 24;
	     emp.phoneNumber = "7875123828";
	     emp.address = "patoda,yeola nashik";
	     emp.salary = 30000;
	     emp.specialization = "Software Engineer";

	    
	     m.name = "Pankaj";
	     m.age = 24;
	     m.phoneNumber = "8876543210";
	     m.address = "sangamner";
	     m.salary = 60000;
	     m.department = "Full stack Developer";

	     
	     System.out.println("Employee details :");
	     System.out.println("Name: " + emp.name);
	     System.out.println("Age: " + emp.age);
	     System.out.println("Phone Number: " + emp.phoneNumber);
	     System.out.println("Address: " + emp.address);
	     emp.printSalary(); 
	     System.out.println("Specialization: " + emp.specialization);
	     System.out.println("**************************");

	     System.out.println("Manager details:");
	     System.out.println("Name: " + m.name);
	     System.out.println("Age: " + m.age);
	     System.out.println("Phone Number: " + m.phoneNumber);
	     System.out.println("Address: " + m.address);
	     m.printSalary(); 
	     System.out.println("Department: " + m.department);
	 }

}
