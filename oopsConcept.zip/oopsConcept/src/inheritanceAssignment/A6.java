package inheritanceAssignment;
/*Create a class rectangle and use inheritance to create another class cuboid. 
create methods to calculate area & volume and also create getters and setters*/

public class A6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle6 r = new Rectangle6(5, 10);
        System.out.println("Rectangle area: " + r.area());

        Cuboid c = new Cuboid(5, 10, 15);
        System.out.println("Cuboid volume: " + c.volume());
	}

}
