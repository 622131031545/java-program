package inheritanceAssignment;
//Create a class circle and use inheritance to create another class cylinder from it.
public class Cylinder extends Circle5 {
 private double height;

 public Cylinder(double radius, double height) {
     super(radius);
     this.height = height;
 }

 public double getHeight() {
     return height;
 }

 public double volume() {
     return area() * height;
 }

 public double surfaceArea() {
     return 2 * area() + circumference() * height;
 }
}
