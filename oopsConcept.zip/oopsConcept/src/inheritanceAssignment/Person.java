package inheritanceAssignment;

class Person {
    private String lastName;
    
    public Person(String lastName) {
        this.lastName = lastName;
    }
    
    public String getLastName() {
        return lastName;
    }
}