package holidayAssignment;
/*1) The Java class called Holidayis started below. An object of class Holidayrepresents a
holiday during the year. This class has three instance variables:
● name, which is a Stringrepresenting the name of the holiday
● day, which is an intrepresenting the day of the month of the holiday
● month, which is a Stringrepresenting the month the holiday is in
public class Holiday {
private String name;
private int day;
private String month;
// your code goes here
}
a) Write a constructor for the class Holiday, which takes a Stringrepresenting the name, an
intrepresenting the day, and a Stringrepresenting the month as its arguments, and sets the
class variables to these values.
b) Write a method inSameMonth, which compares two instances of the class Holiday,and
returns the Boolean value trueif they have the same month, and falseif they do not.
c) Write a method avgDatewhich takes an array of base type Holidayas its argument, and
returns a doublethat is the average of the dayvariables in the Holidayinstances in the
array. You may assume that the array is full (i.e. does not have any null entries).
d) Write a piece of code that creates a Holidayinstance with the name “Independence Day”,
with the day “4”, and with the month “July”.*/
public class Holiday {

	private String name;
    private int day;
    private String month;
    
  
    public Holiday(String name, int day, String month) {
        this.name = name;
        this.day = day;
        this.month = month;
        
    }
    public boolean inSameMonth(Holiday otherHoliday) {
    	if(this.month==otherHoliday.month) {
    		return true;
    	}
    	else
    	{
    		return false;
    	}
      
    }
   /* public boolean inSameMonth(Holiday otherHoliday) {
        return this.month.equals(otherHoliday.month);
    }*/
    public static double avgDate(Holiday[] holidays) {
        int sum = 0;
        for (int index = 0; index < holidays.length; index++){
            sum = sum = +holidays[index].day;
       }
         return (double) sum/ holidays.length;
       
    }
    public static void main(String[] args) {
        
        Holiday independenceDay = new Holiday("Independence Day", 4, "July");
       
        System.out.println("Name: " + independenceDay.name);
        System.out.println("Day: " + independenceDay.day);
        System.out.println("Month: " + independenceDay.month);
    }
}
