package mLI;

class Vehicle {
	 int numberOfWheels;
	    String type;
	    public Vehicle(int numberOfWheels, String type) {
	        this.numberOfWheels = numberOfWheels;
	        this.type = type;
	    }
	    void display() {
	        System.out.println("Type: " + type);
	        System.out.println("Number of Wheels: " + numberOfWheels);
	    }
   
}
class Bicycle extends Vehicle {
   
	  public Bicycle(int numberOfWheels, String type) {
	        super(numberOfWheels, type);
	    }


	
}
class MountainBicycle extends Bicycle {
    
    public MountainBicycle(int numberOfWheels, String type) {
        super(numberOfWheels, type);
    }
}
public class MultilevelInherirance {

	public static void main(String[] args) {
		 Vehicle v = new Vehicle(4, "vehicle");
	        Bicycle b = new Bicycle(2, "bicycle");
	        MountainBicycle mb = new MountainBicycle(2, "mountain bicycle");
	        System.out.println("Vehicle:");
	        v.display();
	        System.out.println();

	        System.out.println("Bicycle:");
	        b.display();
	        System.out.println();

	        System.out.println("Mountain Bicycle:");
	        mb.display();
		 
		
	}

}
