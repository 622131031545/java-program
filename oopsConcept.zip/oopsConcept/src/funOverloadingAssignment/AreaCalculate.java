package funOverloadingAssignment;
/**Create a class to print the area of a square and a rectangle. 
 * The class has two methods with the same name but different number of parameters. 
 * The method for printing area of rectangle has two parameters which are length and breadth respetively 
 * while the other method for printing area of square has one parameter which is side of square.
**/
public class AreaCalculate {
    public void printingArea(int length, int breadth) {
        int area = length * breadth;
        System.out.println("Area of Rectangle: " + area);
    }

    public void printingArea(int side) {
        int area = side * side;
        System.out.println("Area of Square: " + area);
    }
    public static void main(String[] args) {
    	AreaCalculate c = new AreaCalculate();
        
      
        c.printingArea(3, 2);
        c.printingArea(4);  
    }
}
