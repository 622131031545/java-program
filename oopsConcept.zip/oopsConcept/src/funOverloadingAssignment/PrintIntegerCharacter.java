package funOverloadingAssignment;
/**Create a class to print an integer and a character with two methods having the same name but different 
 * sequence of the integer and the character parameters.
For example, if the parameters of the first method are of the form (int n, char c), then that of the second method will be of the form (char c, int n).**/

public class PrintIntegerCharacter {
   
    public void print(int n, char c) {
        System.out.println("Integer : " + n + " Character: " + c);
    }

    public void print(char c, int n) {
        System.out.println("Character : " + c + " Integer: " + n);
    }


    public static void main(String[] args) {
        PrintIntegerCharacter p = new PrintIntegerCharacter();
       
        p.print(5, 'b'); 
        p.print('a', 5);
    }
}
