package funOverloadingAssignment;
/**Create a class named 'PrintNumber' to print various numbers of different 
 * datatypes by creating different methods with the same name 'printn' having a parameter for each datatype.***/
public class PrintNumber {
   
    public void printn(int num) {
        System.out.println("Integer: " + num);
    }
    public void printn(float num) {
        System.out.println("Float: " + num);
    }
    public void printn(double num) {
        System.out.println("Double: " + num);
    }

    public void printn(long num) {
        System.out.println("Long: " + num);
    }

    public void printn(short num) {
        System.out.println("Short: " + num);
    }
    public void printn(byte num) {
        System.out.println("Byte: " + num);
    }
    public void printn(boolean flag) {
        System.out.println("Boolean: " + flag);
    }

    public void printn(char ch) {
        System.out.println("Character: " + ch);
    }

    public void printn(String str) {
        System.out.println("String: " + str);
    }

    public static void main(String[] args) {
        PrintNumber p = new PrintNumber();
        p.printn(5);
        p.printn(3.14f);
        p.printn(2.5);
        p.printn(23241000000000000L);       
        p.printn('A');
        p.printn("Shaibaj");
        p.printn((short)10);
        p.printn((byte)4);
        p.printn(true);
    }
}
