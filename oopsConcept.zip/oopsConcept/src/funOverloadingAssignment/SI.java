package funOverloadingAssignment;
/****5 .write a function to calculate SI for
a fixed year
b fixed roi,
c variable year and roi
*****/
public class SI {

    void calculateSI(double principal, int years, double rate) {
    	 System.out.println("SI for fixed year and fixed rate of interest: "+(principal * years * rate / 100));
    }

    
    void calculateSI(double principal, int years) {
        System.out.println("SI for  year and fixed rate of interest: "+((principal * years * 10) / 100));
    }

    void calculateSI(double principal, double rate) {
       System.out.println("SI for fixed year and  rate of interest: "+((principal * 2 * rate) / 100));
    }

    
    public static void main(String[] args) {
        SI c = new SI();
       c.calculateSI(8000, 2, 3);
       c.calculateSI(1200, 2);
       c.calculateSI(3000, 4);
       
    }
}

