package funOverloadingAssignment;
// Design a class Shape to calculate the area of a different shape by overloading area().
public class Shape {
	void area(double radius) {
        System.out.println("Area of circle: "+(3.14 * radius * radius));
    }
    void area(double length, double width) {
       System.out.println("Area of rectangle: "+(length * width));
    }

    public static void main(String[] args) {
        Shape s = new Shape();

        s.area(5.0);
        s.area(4.0, 3.0);      
       
     
    }
}

