package funOverloadingAssignment;
//write a function to add two floats, integers, doubles
public class Addition {

    void add(float a, float b) {
        System.out.println("Adition of Float :"+(a+b));
    }
    void add(int a, int b) {
    	 System.out.println("Adition of Integer :"+(a+b));
    }

    
    void add(double a, double b) {
    	 System.out.println("Adition of Double :"+(a+b));
    }

    public static void main(String[] args) {
        Addition a = new Addition();
        a.add(2.5f, 2.5f);
        a.add(3, 2);
        a.add(3.5, 5.5);
        
    }
}
