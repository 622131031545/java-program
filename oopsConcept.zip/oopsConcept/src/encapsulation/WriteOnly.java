package encapsulation;

public class WriteOnly {
private int num1;
private int num2;

public void setNum1(int num1) {
	this.num1 = num1;
}

public void setNum2(int num2) {
	this.num2 = num2;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WriteOnly w=new WriteOnly();
		w.setNum1(10);
		w.setNum2(20);
	}

}
