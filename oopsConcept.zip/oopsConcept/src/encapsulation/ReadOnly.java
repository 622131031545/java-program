package encapsulation;

public class ReadOnly {
private int num1=10;
private int num2=20;

	public int getNum1() {
	return num1;
}

public int getNum2() {
	return num2;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadOnly ro=new ReadOnly();
		System.out.println("Number are \n "+ro.getNum1()+ " \n"+ro.getNum2());
		
	}

}
