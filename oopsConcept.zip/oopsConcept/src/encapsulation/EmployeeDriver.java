package encapsulation;
class Employee{
private	int empId;
private	String empName;
private	int age;
private	String designation;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}

}
public class EmployeeDriver {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee();
		e.setEmpId(101);
		e.setEmpName("shaibaj");
		e.setAge(24);
		e.setDesignation("Trainee software Developer");
		System.out.println(e.getEmpName()+ " is " +e.getDesignation());
	}

}
