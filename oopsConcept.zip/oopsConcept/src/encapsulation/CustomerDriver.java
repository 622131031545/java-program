package encapsulation;
class Customer{
private	int customernumber;
private	String custName;
private	String custAddress;
private String email;
private String Product;

public String getProduct() {
	return Product;
}
public void setProduct(String product) {
	this.Product = product;
}
public void setCustomernumber(int customernumber) {
	this.customernumber = customernumber;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public void setCustAddress(String custAddress) {
	this.custAddress = custAddress;
}
public int getCustomernumber() {
	return customernumber;
}
public String getCustName() {
	return custName;
}
public String getCustAddress() {
	return custAddress;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}

}
public class CustomerDriver {

	public static void main(String[] args) {
		Customer c=new Customer();
		c.setCustomernumber(1001);
		c.setCustName("shaibaj");
		c.setCustAddress("nashik");
		c.setEmail("shaibaj1998@gmail.com");
		c.setProduct("mobile");
		System.out.println("Customer Detail are");
		System.out.println("Customer Number :"+c.getCustomernumber());
		System.out.println("Customer Name :"+c.getCustName()+"\nCustomer Address is:"+c.getCustAddress());
		System.out.println("Custome Mail :"+c.getEmail());
		System.out.println("Customer Product :"+c.getProduct());

	}

}
