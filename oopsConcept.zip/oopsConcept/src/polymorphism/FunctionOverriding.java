package polymorphism;

class Base{
	  void call() {
		System.out.println("Base class call method");
	}
	public void callMe() {
		System.out.println("Base class callMe method");
			
	}
}
class Derived extends Base{
	//overriden method
	 void call() {
		System.out.println("Derived class call method");
	}
	public void callMeToo() {
		
	}
}
public class FunctionOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Derived d=new Derived();
		d.call();  //base class call method is overriden by derived class
		*/
		Base b;
		b=new Base();
		b.call();
		b.callMe();
		b=new Derived();
		b.call();
		// b.callMeToo(); non-overriden method call is not allowed
	}

}

