package polymorphism;

public class MethodOverloading {
	void addition(int num1,int num2) {
		System.out.println("Addition of "+num1+" and "+num2+" is "+(num1+num2));
	}
	void addition(float num1,float num2) {
		System.out.println("Addition of "+num1+" and "+num2+" is "+(num1+num2));
		
	}
	void addition(int num1,int num2,int num3) {
		System.out.println("Addition of "+num1+","+num2+" and "+num3+" is "+(num1+num2+num3));
		
	}
	public static void main(String args) {
		MethodOverloading mo=new MethodOverloading();
		mo.addition(2.3f, 3.4f);
		mo.addition(2, 10);
		mo.addition(11, 12, 13);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodOverloading mo=new MethodOverloading();
		mo.addition(2.3f, 3.4f);
		mo.addition(2, 10);
		mo.addition(11, 12, 13);
	}

}
