package polymorphism;

class BaseCon{
	 public BaseCon() {
		 System.out.println("Base's class constructor");
	 }
	 
}
class DerivedCon extends BaseCon{
	/*public BaseCon() {
		 System.out.println("Base's class constructor");
	 }*/
	public DerivedCon() {
		System.out.println("Defualt's class constructor");
	}
}
public class ConstructorOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
