package polymorphism;

public class SquareMO {
	void square(int num) {
		System.out.println("Sqaure of "+num+" is "+(num*num));
	}
	void square(float num) {
		System.out.println("Sqaure of "+num+" is "+(num*num));
	}
	void square(double num) {
		System.out.println("Sqaure of "+num+" is "+(num*num));
	}
	void square(long num) {
		
		System.out.println("Sqaure of "+num+" is "+(num*num));
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SquareMO s=new SquareMO();
		s.square(5);
		s.square(5.2f);
		s.square(5.5);
		s.square(5.2222);
		
	}

}
