package polymorphism;

public class ConstructorMO {
	int num1;
	int num2;
public ConstructorMO() {
		
		this.num1 = 10;
		this.num2 = 20;
	}
	public ConstructorMO(int num1, int num2) {
		
		this.num1 = num1;
		this.num2 = num2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorMO c=new ConstructorMO();
		ConstructorMO c1=new ConstructorMO(5,2);
	}

}
