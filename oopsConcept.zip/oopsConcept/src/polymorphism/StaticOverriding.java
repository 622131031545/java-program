package polymorphism;

class StaticBase{
	 static void call() {
		 System.out.println("Base class static method");
	 }
}
public class StaticOverriding extends StaticBase{
	static void call() {
		 System.out.println("Derived class static method");
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		call();
}
}
