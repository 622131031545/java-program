package polymorphism;

public class MainMethodOverloading {

	public static void main(int num) {
		System.out.println("First overloaded form of main method");
	}
	public static void main(String names) {
		System.out.println("Second overloaded form of main method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		main(10);
		main("Overloading");

	}

}
