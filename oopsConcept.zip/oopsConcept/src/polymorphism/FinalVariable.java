package polymorphism;

public class FinalVariable {

	final  int number=10;
	final int number1;
	static final  int number3=30;
	/*public FinalVariable() {
		number1=20;
	}*/
	{
		number1=20;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalVariable fv=new FinalVariable();
		System.out.println("Final variable value is "+fv.number);
		//fv.number=30; not allowed
		System.out.println("Final variable value is "+fv.number1);
		System.out.println(fv.number3);
	}

}
