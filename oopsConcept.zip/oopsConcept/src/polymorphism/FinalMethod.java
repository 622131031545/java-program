package polymorphism;

class FinalParent{
	final public void call() {
		System.out.println("Base class call method");
	}
	final public void call(String msg) {
		System.out.println("Base class call method");
	}
}
public class FinalMethod extends FinalParent {

	/*   final methods cannot be overriden
	 * public void call() {
		System.out.println("Derived class call method");
	}*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
