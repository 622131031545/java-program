package polymorphism;

public class StaticOverloading {

	public static void greet() {
		System.out.println("Welcome to method overloading");
	}
	public static void greet(String msg) {
		System.out.println(msg);
	}
	public static void greet(int num) {
		System.out.println(num);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		greet();
		greet(3);
		greet("Good Morning");
	}

}
