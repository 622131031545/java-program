package polymorphism;

public class ConstructorOverloading {

	int num1;
	int num2;
	//Constructor Overloading
	public ConstructorOverloading() {
		this.num1=10;
		this.num2=40;
	}
	public ConstructorOverloading(int num1,int num2) {
		this.num1=num1;
		this.num2=num2;
	}
	public ConstructorOverloading(int num1) {
		this.num1=num1;
		
	}
	public ConstructorOverloading(float num2) {
				this.num2=(int) num2;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
            ConstructorOverloading co1=new ConstructorOverloading();
            ConstructorOverloading co2=new ConstructorOverloading(5);
            ConstructorOverloading co3=new ConstructorOverloading(5.7f);
            ConstructorOverloading co4=new ConstructorOverloading(3,4);
            
	}

}
