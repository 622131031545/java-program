package polymorphism;

final class FinalC{
	 public void call() {
		 System.out.println("Base class call method");
			
	 }
}
public class FinalClass //extends FinalC  final class can not be inherited
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
