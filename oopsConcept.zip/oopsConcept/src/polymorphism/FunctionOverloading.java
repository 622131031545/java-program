package polymorphism;

public class FunctionOverloading {
 
	 void addition(int num1,int num2) {
		System.out.println("Addition of "+num1+" and "+num2+" is "+(num1+num2));
	}
	 void addition(float num1,float num2) {
		System.out.println("Addition of "+num1+" and "+num2+" is "+(num1+num2));
		
	}
	 void addition(int num1,int num2,int num3) {
		System.out.println("Addition of "+num1+","+num2+" and "+num3+" is "+(num1+num2+num3));
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionOverloading fo=new FunctionOverloading();
		fo.addition(2.3f, 3.4f);
		fo.addition(2, 10);
		fo.addition(11, 12, 13);
	}

}
