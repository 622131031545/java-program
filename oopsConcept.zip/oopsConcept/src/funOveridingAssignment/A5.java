package funOveridingAssignment;
/*5. All the banks operating in India are controlled by RBI.
 *  RBI has set a well defined guideline
 *   (e.g. minimum interest rate, minimum balance allowed, maximum withdrawal limit etc) 
 *   which all banks must follow. 
 *   For example, suppose RBI has set minimum interest rate applicable to a saving bank account
 *    to be 4% annually; however, banks are free to use 4% interest rate or to set any rates above it.
Write a JAVA program to implement bank functionality in the above scenario and 
demonstrate the dynamic polymorphism concept. Note: Create few classes namely Customer, Account, RBI (Base Class) and few derived classes (SBI, ICICI, PNB etc). Assume and implement required member variables and functions in each class.

Hint:
Class Customer
{
//Personal Details ...
// Few functions ...
}
Class Account
{
// Account Detail ...
// Few functions ...
}
Class RBI
{
Customer c; //hasA relationship
Account a; //hasA relationship
..
Public double GetInterestRate() { }
Public double GetWithdrawalLimit() { }
}
Class SBI: public RBI
{
//Use RBI functionality or define own functionality.
}
Class ICICI: public RBI
{
//Use RBI functionality or define own functionality.
}*/
class RBI {
 
double min_interest_rate = 4.0;
static double min_balance = 1000.0;
 double max_withdrawal_limit = 50000.0;



public static double getMinBalance() {
	return min_balance;
}


public double getInterestRate() {
     return min_interest_rate;
 }

 
 public double getMinimumBalance() {
     return min_balance;
 }


 public double getMaxWithdrawalLimit() {
     return max_withdrawal_limit;
 }
}


class Customer {

}

class Account {
 
}

class SBI extends RBI {

}

class ICICI extends RBI {
 
}

class PNB extends RBI {

}

public class A5 {

	public static void main(String[] args) {
	   
	     RBI sbi = new SBI();
	     RBI icici = new ICICI();
	     RBI pnb = new PNB();
	     System.out.println("SBI Interest Rate: " + sbi.getInterestRate());
	     System.out.println("ICICI Minimum Balance: " + icici.getMinimumBalance());
	     System.out.println("PNB Maximum Withdrawal Limit: " + pnb.getMaxWithdrawalLimit());
	 }

}
