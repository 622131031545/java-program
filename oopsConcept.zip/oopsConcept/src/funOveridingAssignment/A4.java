package funOveridingAssignment;
/*4. Suppose a class 'A' has a static method to print "Parent".
 *  Its subclass 'B' also has a static method with the same name to print "Child".
 *   Now call this method by the objects of the two classes. 
 *   Also, call this method by an object of the parent class refering to
 *    the child class i.e. A obj = new B()
*/

class A {
 
 static void print() {
     System.out.println("Parent");
 }
}

class B extends A {
 
 static void print() {
     System.out.println("Child");
 }
}

public class A4 {
	public static void main(String[] args) {
	     
	     A.print(); 
	     B.print(); 
	     A obj = new B();
	  
	     obj.print();  
	 }
}
