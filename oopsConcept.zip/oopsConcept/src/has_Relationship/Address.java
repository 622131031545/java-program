package has_Relationship;

public class Address {
int flatno;
int laneno;
String area;
String city;
String country;
int zipcode;
public Address(int flatno, int laneno, String area, String city, String country, int zipcode) {
	super();
	this.flatno = flatno;
	this.laneno = laneno;
	this.area = area;
	this.city = city;
	this.country = country;
	this.zipcode = zipcode;
}

	


}
