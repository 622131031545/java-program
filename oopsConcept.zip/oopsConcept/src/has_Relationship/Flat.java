package has_Relationship;

public class Flat {
	int flatNumber;
    int numOfRooms;
    double squareFootage;
	public Flat(int flatNumber, int numOfRooms, double squareFootage) {
		
		this.flatNumber = flatNumber;
		this.numOfRooms = numOfRooms;
		this.squareFootage = squareFootage;
	}
    
}
