package has_Relationship;

public class Building {
	String buildingName;
    String address;
    int numOfFloors;
    double totalArea;
    Flat f;
	public Building(String buildingName, String address, int numOfFloors, double totalArea, Flat f) {
		
		this.buildingName = buildingName;
		this.address = address;
		this.numOfFloors = numOfFloors;
		this.totalArea = totalArea;
		this.f = f;
	}
	public void showBuildingDetails()
	{
		System.out.println("Building Name :"+this.buildingName+"\nAddress :"+this.address+"\nNumber of Floors :"+this.numOfFloors+"\nTotal Area :"+this.totalArea);
		System.out.println("Flat Number :"+this.f.flatNumber+"\nNumber of Rooms :"+this.f.numOfRooms+"\nSquare Fotage :"+this.f.squareFootage);
	}
    
}
