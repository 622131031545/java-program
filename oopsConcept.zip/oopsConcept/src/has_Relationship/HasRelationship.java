package has_Relationship;

public class HasRelationship {

	public static void main(String[] args) {
		Address add=new Address(102,11,"patoda","yeola","India",423401);
		Person p=new Person("shaibaj",62310545,698,add);
p.show();
	}

}
