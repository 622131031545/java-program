package has_Relationship;

public class HasRelationshipAss {

	public static void main(String[] args) {
		
		Flat f=new Flat(3,10,100.5);
		Building b=new Building("Deshmukh","patoda yeola",5,1000.9,f);
		b.showBuildingDetails();
	}

}
