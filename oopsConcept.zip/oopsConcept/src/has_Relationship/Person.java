package has_Relationship;

public class Person {
	String name;
	int adharno;
	int age;
	Address add;
	public Person(String name, int adharno, int age, Address add) {
		
		this.name = name;
		this.adharno = adharno;
		this.age = age;
		this.add = add;
	}
	
public void show() {
	System.out.println("Name :"+this.name+"\nAadhar no :"+this.adharno+"\nAge :"+this.age);
	System.out.println("Address "+this.add.flatno+"\nlan no :"+this.add.laneno+"\nArea :"+this.add.area+"\ncity :"+this.add.city+"\ncountry :"+this.add.country+"\n pincode :"+this.add.zipcode);
}
}
