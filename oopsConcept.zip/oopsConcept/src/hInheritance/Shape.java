package hInheritance;

public class Shape {

	double area;

	public double area() {
		return area;
	}

}
