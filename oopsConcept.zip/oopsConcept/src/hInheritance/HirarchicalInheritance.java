package hInheritance;

public class HirarchicalInheritance {

	public static void main(String[] args) {
		       

        Circle circle = new Circle(5);
        System.out.println("Circle of Area: " + circle.area());
        System.out.println("***********");
        
        Square square = new Square(4);
        System.out.println("Square of Area: " + square.area());      
        System.out.println("*********");
        
        Rectangle rectangle = new Rectangle(3, 5);      
        System.out.println("Rectangle of Area: " + rectangle.area());
      
        System.out.println("***************");

        Triangle triangle = new Triangle(3, 4);
        System.out.println(" Triangle Area: " + triangle.area());
       
	}

}
