package interfaceJava;

public interface Shape {
	 double getArea();
}

