package interfaceJava;

public class InterfaceImp2  implements Interface1{
public static void main() {
	InterfaceImp2 i=new InterfaceImp2();
	i.show();
}

@Override
public void show() {
	// TODO Auto-generated method stub
	System.out.println("Method Interface");
	
}
}
