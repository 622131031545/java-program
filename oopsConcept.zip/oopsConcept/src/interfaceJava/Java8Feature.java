package interfaceJava;

public class Java8Feature implements Interface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Java8Feature jf=new Java8Feature();
      jf.show();
      Interface2.display();
     
	}

}
