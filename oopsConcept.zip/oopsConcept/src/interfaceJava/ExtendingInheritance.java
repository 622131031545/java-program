package interfaceJava;
interface RBI{
	void getROI();

}
interface SBI extends RBI{
	void getPlans();
	

	
	
	
	
}

public class ExtendingInheritance {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ExtendingInheritance ei=new ExtendingInheritance();
		ei.getROI();
		ei.getPlans();
		
	}
	
	public void getROI() {
		// TODO Auto-generated method stub
		System.out.println("Parent interface method");
	}

	
	public void getPlans() {
		// TODO Auto-generated method stub
		System.out.println("Child interface method");

	}
}
