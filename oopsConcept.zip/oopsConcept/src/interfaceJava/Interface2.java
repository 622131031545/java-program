package interfaceJava;
public interface Interface2 {
   default void show() {
    	System.out.println("From Java8 interface allows to define methods with defualt specifier");
    	call();
   }
   static void display() {
	   System.out.println("From Java8 interface allows to define methods with static keyword");
	   callMe();
   }
   private void call() {
	   System.out.println("From Java9 interface allows to define methods with private specifier");
		 
   }
   private static void callMe() {
	   System.out.println("From Java9 interface allows to define methods with private specifier and static keyword");
		 
   }
}
