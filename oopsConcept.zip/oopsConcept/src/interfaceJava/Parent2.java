package interfaceJava;

public interface Parent2 {
	void call();
	void callMeToo();
	void callMe();
}
