package interfaceJava;

public interface Parent1 {
void call();
void callMeToo();
}