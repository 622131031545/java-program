package interfaceJava;

public class Child implements Parent1,Parent2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Child c=new Child();
c.call();
c.callMeToo();
c.callMe();

	}

	@Override
	public void call() {
		// TODO Auto-generated method stub
		System.out.println("call Parent1");
	}

	@Override
	public void callMeToo() {
		// TODO Auto-generated method stub
		System.out.println("callme too Parent1");
	}

	@Override
	public void callMe() {
		// TODO Auto-generated method stub
		System.out.println("call me Parent2");
	}

	

}
