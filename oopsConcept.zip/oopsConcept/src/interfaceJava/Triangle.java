package interfaceJava;

class Triangle implements Shape {
    private double base;
    private double height;

    public Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    @Override
    public double getArea() {
        return 0.5 * base * height;
    }
    public static void main(String[] args) {
        Rectangle r = new Rectangle(3, 2);
        Circle c = new Circle(5);
        Triangle t = new Triangle(2, 5);

        System.out.println("Area of Rectangle: " + r.getArea());
        System.out.println("Area of Circle: " + c.getArea());
        System.out.println("Area of Triangle: " + t.getArea());
    }
}