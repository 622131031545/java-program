package interfaceJava;

public interface Interface1 {
	   public static int number=30;
	   public  void show();
}
