package interfaceJava;

public class InterfaceImpl implements Interface1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterfaceImpl ii=new InterfaceImpl();
		ii.show();
		System.out.println(Interface1.number);
	}

	@Override
	public void show() {
		System.out.println("method of interface");
		
	}

}
