package inheritance;

public class MultilevelInheritance {

	public static void main(String[] args) {
		
		 Vehicle v = new Vehicle(4, "vehicle", "BMW");
	        Bicycle b = new Bicycle(2, "bicycle", "Honda Bicycle");
	        MountainBicycle m = new MountainBicycle(2, "mountain bicycle", "Hero Mountain Bicycle");

	        System.out.println("Vehicle are");
	        v.display();
	        System.out.println();

	        System.out.println("Bicycle are");
	        b.display();
	        System.out.println();

	        System.out.println("Mountain Bicycle are");
	        m.display();
	}

}
