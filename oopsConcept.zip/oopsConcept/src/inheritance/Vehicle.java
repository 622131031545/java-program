package inheritance;

public class Vehicle {
	    int numberOfWheels;
	    String type;
	    String name;
	    public Vehicle(int numberOfWheels, String type, String name) {
	        this.numberOfWheels = numberOfWheels;
	        this.type = type;
	        this.name = name;
	    }
	    void display() {
	        System.out.println("Name: " + name);
	        System.out.println("Type: " + type);
	        System.out.println("Number of Wheels: " + numberOfWheels);
	    }
}
