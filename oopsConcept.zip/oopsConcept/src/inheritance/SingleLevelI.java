package inheritance;

class Animal
{
	String type;
	String food;
	String Voice;
	int age;
	
	void setAnimalInfo(String type, String food, String voice, int age) {
		
		this.type = type;
		this.food = food;
		Voice = voice;
		this.age = age;
	}
	void showAnimalInfo()
	{
		System.out.println("Animal Info \n Type :"+this.type+"\n Food :"+this.food +"\n voice :"+this.Voice+"\n Age :"+this.age );
	}
}
class Dog extends Animal{
	String breedType;

	void setDogInfo(String breedType) {
		
		this.breedType = breedType;
	}
	void showDogInfo()
	{
		System.out.println("Dog Info"+this.breedType);
	}
}
public class SingleLevelI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d=new Dog();
		d.setAnimalInfo("pet", "meat","bark", 1);
		d.setDogInfo("jarman Shaphered");
		d.showAnimalInfo();
		d.showDogInfo();
	}

}
