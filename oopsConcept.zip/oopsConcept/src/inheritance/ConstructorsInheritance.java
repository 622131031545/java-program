package inheritance;

class Employee{
	int age;
	int empId;
	String name;
	
	/*public Employee(int empId,String name,int age) {
		this.empId=empId;
		this.name=name;
		this.age=age;
	}*/
	public void showEmployeeInfo() {
		System.out.println("Employee Information\nId :"+this.empId+"\nName "+this.name);
	}
	
}
class PartTimeEmployee extends Employee{
	int whr;
	
	/*public PartTimeEmployee(int empId,String name,int age,int whr) {
		//super(empId,name,age);
		this.whr=whr;
	}*/
	public void showWorkingHours() {
		System.out.println("Total Working hours "+this.whr);
	}
}
public class ConstructorsInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	PartTimeEmployee pte=new PartTimeEmployee(1, "abc", 34, 50);
		PartTimeEmployee pte=new PartTimeEmployee();
		
		pte.showEmployeeInfo();
		pte.showWorkingHours();
	}

}
