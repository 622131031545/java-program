package inheritance;

public class HybridInheritance {

}
