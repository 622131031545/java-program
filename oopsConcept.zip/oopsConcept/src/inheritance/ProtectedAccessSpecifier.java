package inheritance;

class Shape{
	protected int radius;
	public Shape(int radius){
		this.radius=radius;
			
	}
}
class Circle extends Shape{
	public Circle(int radius) {
		super(radius);
		// TODO Auto-generated constructor stub
	}
	public float getArea() {
		return ((float)(3.14*radius*radius));
	}
}
class Sphere{
	public float getArea() {
		//return ((float)(3.14*radius*radius)); radius is not accessible as Sphere is not child of shape
		return 0.0f;
	}
}
public class ProtectedAccessSpecifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c=new Circle(5);
		System.out.println("Circle area is "+c.getArea());
	}

}
