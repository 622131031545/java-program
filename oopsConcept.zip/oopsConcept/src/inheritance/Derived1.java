package inheritance;

	public class Derived1 extends Base {
	     public void display() {
	    	 System.out.println("In Derived class which act as a parent for another class");
	     }
	}

