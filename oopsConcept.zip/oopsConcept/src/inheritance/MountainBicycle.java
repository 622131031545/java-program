package inheritance;

public class MountainBicycle  extends Bicycle {
	
	    public MountainBicycle(int numberOfWheels, String type, String name) {
	        super(numberOfWheels, type, name);
	    }
	}
