package inheritance;

class Parent{
	int num;
	public void call() {
		System.out.println("Member function of base class");
	}
}
class Child extends Parent{
	int num;
	public void call() {
		super.call();
		super.num=30;
		this.num=40;
		System.out.println("Member function of child class");
		System.out.println("Parent's num value is "+super.num+"\nChild's num value is "+this.num);
	}
}
public class SuperKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child c=new Child();
		//c.num=20;
		c.call();
	}

}
