package inheritance;

public class Semicircle extends Shape{
	public Semicircle(int radius) {
		super(radius);
		// TODO Auto-generated constructor stub
	}
	public float getArea() {
		return ((float)(0.2*3.14*radius*radius));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Semicircle sc=new Semicircle(4);
		System.out.println("Circle area is "+sc.getArea());

	}

}
