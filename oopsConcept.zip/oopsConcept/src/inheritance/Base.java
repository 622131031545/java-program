package inheritance;

public class Base {

	
	public void show() {
		System.out.println("Base class");
	}
}
