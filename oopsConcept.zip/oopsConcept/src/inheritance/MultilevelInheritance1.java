package inheritance;


public class MultilevelInheritance1 extends Derived1 {

	public void call() {
		System.out.println("Grand child of Base class and Child of Derived1");
	}
	public static void main(String[] args) {
		MultilevelInheritance1 ml=new MultilevelInheritance1();
		ml.call();
		ml.display();
		ml.show();

	}

}