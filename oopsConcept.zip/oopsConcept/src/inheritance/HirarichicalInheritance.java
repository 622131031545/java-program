package inheritance;

public class HirarichicalInheritance extends Base{

	public void call() {
		System.out.println("Another child of Base class");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HirarichicalInheritance hi=new HirarichicalInheritance();
		hi.call();
		hi.show();
	}

}
