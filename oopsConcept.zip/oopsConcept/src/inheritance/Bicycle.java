package inheritance;

public class Bicycle extends Vehicle {
	
	public Bicycle(int numberOfWheels, String type, String name) {
	    super(numberOfWheels, type, name);
	}
}
