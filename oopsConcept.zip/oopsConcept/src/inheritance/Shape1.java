package inheritance;

public class Shape1 {
	protected int radius;
	public Shape1(int radius) {
		this.radius=radius;
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
