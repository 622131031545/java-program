package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCUPDATE {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// step 1 register the driver
		Connection con=null;
		Statement stmt=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step 2 establish the connection
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java","root","root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step 3 create statement
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// step 4 execute the query
		try {
			int resUpdated=stmt.executeUpdate("update student set Age=25 where Roll_No=3");
		if(resUpdated!=0)
		
			System.out.println("Age updated successfully");
		else
			System.out.println("Age not updated ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step 5 close connection
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
