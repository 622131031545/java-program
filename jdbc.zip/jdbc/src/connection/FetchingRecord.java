package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class FetchingRecord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// step 1 register the driver
		Connection con=null;
		Statement stmt=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step 2 establish the connection
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java","root","root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step 3 create statement
		try {
			stmt=con.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// step 4 execute the query
		try {
			int res=stmt.executeUpdate("insert into student values(6,'a','y','z','male',26)");
		if(res!=0)
		
			System.out.println("Record inserted successfully");
		else
			System.out.println("Record not inserted ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step 5 close connection
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
