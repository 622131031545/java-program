package Assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Join {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement stmt=null;
		
		try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
		
		      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java", "root", "root");
		     
		      stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		      
		    
		      ResultSet rs=stmt.executeQuery("\r\n"
		      		+ "select employee.empId, employee.fname,employee.mname, employee.lname,employee.designation,department.dname,department.Contact_no from employee left outer join department on employee.DeptId=department.DId;");
		     // ResultSet rs=stmt.executeQuery("select employee.empId, employee.fname,employee.mname, employee.lname,employee.designation,department.dname,department.Contact_no from employee join department on employee.DeptId=department.DId;");
		      //  ResultSet rs=stmt.executeQuery( "select employee.empId, employee.fname,employee.mname, employee.lname,employee.designation,department.dname,department.Contact_no from employee right outer join department on employee.DeptId=department.DId;");
			    
		     System.out.println("empId fname mname lname designation dname Contact_no");
		    
		     
		
		
		   
		     while(rs.next()){
		 
		    	 System.out.print(rs.getInt(1) + "\t ");
	                System.out.print(rs.getString(2) + "\t ");
	                System.out.print(rs.getString(3) + "\t ");
	                System.out.print(rs.getString(4) + "\t ");
	                System.out.print(rs.getString(5) + "\t ");
	                System.out.print(rs.getString(6) + "\t\t ");
	                System.out.print(rs.getInt(7)+"\t\t");
	                System.out.println();
		      }
		
		      con.close();
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
	
	}

}
