package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class ResultSetMetaDataDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement stmt=null;
		try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
		
		      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java", "root", "root");
		     
		      stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		      
		      ResultSet rs=stmt.executeQuery("select * from student");
		      int i=1;
		      ResultSetMetaData rsmd=rs.getMetaData();
		      System.out.println("Table name "+rsmd.getTableName(1));
		      System.out.println("Total Number of columns "+rsmd.getColumnCount());
		      System.out.println("Column Information\nSr.No\tColumn name\t type");
		      while(i<=rsmd.getColumnCount()) {
		    	 System.out.println(i+"\t"+rsmd.getColumnLabel(i)+"\t"+rsmd.getColumnType(i)); 
		         i++;
		      }
		      con.close();
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
