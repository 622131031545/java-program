package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Insertion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement stmt=null;
		int rno,age;
		String fname,mname,lname;
		
		//step1 register the drivers
		try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//step2 establish the connection.
		try {
		   con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java", "root", "root");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       // step3 create statement
		    try {
				stmt=con.createStatement();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  // step4 execute the query 
		    try {
		    	   Scanner sc=new Scanner(System.in);
		    	   System.out.println("Enter Roll number");
		    	   rno=sc.nextInt();
		    	   System.out.println("Enter First name");
		    	   fname=sc.next();
		    	   System.out.println("Enter Middle name");
		    	   mname=sc.next();
		    	   System.out.println("Enter Last name");
		    	   lname=sc.next();
		    	   System.out.println("Enter age");
		    	   age=sc.nextInt();
				int res=stmt.executeUpdate("insert into student values("+rno+",'"+fname+"',"+"'"+mname+"',"+"'"+lname+"',"+age+")");
			    if (res!=0)
			    	 System.out.println("Record inserted successfully");
			    else
			    	 System.out.println("Record not inserted");
		    } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
       //step 5 close the connection
		    try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
	}

}
