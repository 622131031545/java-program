package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FetchingRecords {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement stmt=null;
		
		try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
		
		      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java", "root", "root");
		     
		      stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		      
		      ResultSet rs=stmt.executeQuery("select * from student order by rollNum desc");
		     System.out.println("Roll Number First Name  Middle Name  Last Name  Age");
		      //while(rs.next()){
		     
		   //  rs.first();
		    // rs.absolute(3);
		     rs.last();
		    	   System.out.print(rs.getInt(1)+"\t ");
		    	   System.out.print(rs.getString(2)+"\t ");
		    	   System.out.print(rs.getString(3)+"\t ");
		    	   System.out.print(rs.getString(4)+"\t ");
		    	   System.out.print(rs.getInt(5));
				   System.out.println();
		     //  }
		      
		      con.close();
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
				
			 
	 			
			
	}

}
