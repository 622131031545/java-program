package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

public class PreparedStatement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement stmt=null;
		//step1 register the drivers
		
			  try {
				Class.forName("com.mysql.cj.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
	
		//step2 establish the connection.
	
		   try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java", "root", "root");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String q="UPDATE student SET Age=? WHERE Roll_No=?";
		java.sql.PreparedStatement pstmt=null;
		try {
			pstmt = con.prepareStatement(q);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	try {
		pstmt.setInt(1,26);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	try {
		pstmt.setInt(2,3);
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
		boolean resUpdated=false;
		try {
			resUpdated = pstmt.execute();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if(!resUpdated)
			System.out.println("Age updated successfully");
		else
			System.out.println("Age not updated ");
		
		
		
		// step 5 close connection
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
