package jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseMetaDataDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement stmt=null;
		try {
			  Class.forName("com.mysql.cj.jdbc.Driver");
		
		      con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exucia_java", "root", "root");
		      
		      DatabaseMetaData dbmd=con.getMetaData();
		       
		      System.out.println("Database version "+dbmd.getDatabaseMajorVersion());
		      System.out.println("Product Name "+dbmd.getDatabaseProductName());
		      System.out.println("Driver name "+dbmd.getDriverName());
		      System.out.println("Driver version "+dbmd.getDriverMajorVersion());
		      con.close();
				} 
				catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
