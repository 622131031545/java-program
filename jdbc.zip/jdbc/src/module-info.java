/**
 * 
 */
/**
 * @author Shaibaj
 *
 */
module jdbc {
	requires java.sql;
}