package stringBuffer;

public class StringBufferDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // StringBuffer sb="abc";   gives error as only String objects  are created with "="
		 StringBuffer sb1=new StringBuffer();
		// sb1.append('a');
		 sb1.insert(0, "abcdefghij");
		 System.out.println(sb1);
		 
		 StringBuffer sb2=new StringBuffer(sb1);
		 System.out.println(sb2);
		 
		 StringBuffer sb3=new StringBuffer(6);
		 sb3.insert(0, "abcdefgh");
		 System.out.println(sb3);
		 
		 StringBuffer sb4=new StringBuffer("abc");
		 System.out.println(sb4);
		 
		 System.out.println(sb1.capacity());
		 
		 
	}

}
