/**
 * 
 */
/**
 * @author Shaibaj
 *
 */
module Stringjava {
}