package stringBuilder;

public class StringBuilderDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// St StringBuilder sb="abc";   gives error as only String objects  are created with "="
				 StringBuilder sb1=new StringBuilder();
				// sb1.append('a');
				 sb1.insert(0, "abcdefghij");
				 System.out.println(sb1);
				 
				 StringBuilder sb2=new StringBuilder(sb1);
				 System.out.println(sb2);
				 
				 StringBuilder sb3=new StringBuilder(6);
				 sb3.insert(0, "abcdefgh");
				 System.out.println(sb3);
				 
				 StringBuilder sb4=new StringBuilder("abc");
				 System.out.println(sb4);
				 
				 System.out.println(sb1.capacity());
	}

}
