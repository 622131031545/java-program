package stringBuilder;

public class StringbuilderMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb1=new StringBuilder("Shaibaj");
		StringBuilder sb2=new StringBuilder("Deshmukh");
	/*	sb1.append("shaibaj");//Append the specified string at the end of this string.
		System.out.println("append()-->"+sb1);//append()-->Shaibajshaibaj
		sb1.append(true);
		sb1.append('a');
		sb1.append("shaibaj");
		sb1.append(123);
		sb1.append(45.67);
		
		System.out.println("append()-->"+sb1);//append()-->Shaibajshaibajtrueashaibaj12345.67

		sb2.appendCodePoint(65);
		System.out.println("appendCodePoint()-->"+sb2);//appendCodePoint()-->DeshmukhA
		//Return character asci value 
		 	
		
		System.out.println("capacity()"+sb1.capacity());//
		// Get the capacity of the StringBuffer
		
		System.out.println("CharAt() --->"+sb1.charAt(2));//CharAt --->a
		//It returns char value for the particular index
		
		System.out.println("codePointAt()-->"+sb1.codePointAt(2));//codePointAt-->97 
		//Return character asci value 
		 
		System.out.println("codePointBefore()-->"+sb1.codePointBefore(1));//codePointBefore()-->83
		//Returns the character (Unicode code point) before the specifiedindex
		//return before char char asci value return
		 
		System.out.println("codePointCount()--->"+sb1.codePointCount(0, 2));//codePointCount()--->2
		//char couunt start and ending
		
		System.out.println("compareTo()-->"+sb1.compareTo(sb1));//compareTo()-->0
		// compare two value same return 0,compare two value 1 value is big  return -1
	//compare two value 1 value is small  return 1
		
		System.out.println("length()-->"+sb1.length());//length()-->
		//Returns the length of the string.
		 // Convert to lowercase and uppercase
		
		
        
        System.out.println("equal()-->"+sb1.equals(sb2));//equal()-->false
	//compaires the value of string object return boolean value
	 
	  
		
		 // Substring
        String substring = sb1.substring(0,2); // starting from index 5 till end
        System.out.println("Substring from index 7: " + substring);//Substring from index 7: sh
        System.out.println("substring()-->"+sb1.substring(6));//j
        //	Returns a new string which is the substring of a specified string
     
  
		sb1.delete(0, 2);
		System.out.println("delete()-->"+sb1);//delete()-->aibaj
	//The delete() method of the StringBuffer class deletes the string from the specified beginIndex to endIndex-1.
	 
		
		// Insert a string at position 5
        sb1.insert(5, "Deshmukh");
        System.out.println("insert()-->: " + sb1);//insert()-->: ShaibDeshmukhaj
        //Insert the specified string at the offset indicated position.
        
		
        sb1.replace(3, 5, "SD");
        System.out.println("replace()--> " + sb1);//replace()--> ShaSDaj
        //Replace the substring of the string buffer from startIndex to endIndex-1 with the specified string.
        
        System.out.println("indexOf()-->"+sb1.indexOf("a"));//indexOf()-->2
    	//Returns the index within the string of the first occurrence of the specified character.
        */
        System.out.println("toString()-->"+sb1.toString());//toString()-->shaibaj
    	//Returns the value of a String object
	}

}
