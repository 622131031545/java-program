package string;

public class String4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s3=new String("abc");
		String s4=new String("abc");
		String s1="abc";
		System.out.println(s1==s4);//false
		System.out.println(s1.equals(s4));//true
	
	}

}
