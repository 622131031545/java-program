package string;

public class StringComparision {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
             String str1="abc";
             String str2="pqr";
             String str3="abc";
           /*  System.out.println(str1==str2);
             System.out.println(str1.equals(str2));
             
             
             System.out.println(str1==str3);
             System.out.println(str1.equals(str3));*/
             
             String str4=new String("abc");
             /*  System.out.println(str4==str1);
             System.out.println(str4==str2);
             System.out.println(str4==str3);
             
             System.out.println(str4.equals(str1));
             System.out.println(str4.equals(str2));
             System.out.println(str4.equals(str3));*/
             
             String str5=new String("pqr");
            /* System.out.println(str5==str1);
             System.out.println(str5==str2);
             System.out.println(str5==str3);
             System.out.println(str5==str4);
             
             System.out.println(str5.equals(str1));
             System.out.println(str5.equals(str2));
             System.out.println(str5.equals(str3));
             System.out.println(str5.equals(str4));*/
             
             String str6=new String ("pqr");
           /*  System.out.println(str6==str1);
             System.out.println(str6==str2);
             System.out.println(str6==str3);
             System.out.println(str6==str4);
             System.out.println(str6==str5);*/
             
             System.out.println(str6.equals(str1));
             System.out.println(str6.equals(str2));
             System.out.println(str6.equals(str3));
             System.out.println(str6.equals(str4));
             System.out.println(str6.equals(str5));
	}

}
