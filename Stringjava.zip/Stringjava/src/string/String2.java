package string;
//program    demonstrating constructor
public class String2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1=new String();
		System.out.println(str1);//empty
		str1="string1";
		System.out.println(str1);//string1
		byte array1[]= {65,66,67};
		String str2=new String(array1);
		System.out.println(str2);//ABC
		char array2[]= {'a','b','c'};
		String str3=new String(array2);
		System.out.println(str3);//abc
		String str4=new String("string4");
		System.out.println(str4);//string4
		StringBuffer sb=new StringBuffer("abc");
		String str5=new String(sb);
		System.out.println(str5);//abc
		
		StringBuilder sbb=new StringBuilder("pqr");
		String str6=new String(sbb);
		System.out.println(str6);//pqr
		String str7=new String(array1,1, 3);
        System.out.println(str7);
	}

}
