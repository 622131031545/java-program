package string;

public class string1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String n = null;
		System.out.println(n);
String name="shaibaj";
String name1=new String("Shaibaj");
System.out.println(name);
System.out.println(name1);
System.out.println(name+name1);
String s1="abc";
String s2="abc";
String s3=new String("abc");
String s4=new String("abc");
System.out.println(s1==s2);//false
System.out.println(s1.equals(s2));
System.out.println(s3==s4);//false
System.out.println(s3.equals(s4));//true
s3.concat("pqr");
	System.out.println(s3);
	s3=s3.concat("pqr");
	System.out.println(s3);
	}

}
