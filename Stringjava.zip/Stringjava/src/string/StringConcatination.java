package string;

public class StringConcatination {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String str1="abc";
         String str2="pqr";
         
         System.out.println(str1+str2);
         str1=str1.concat(str2);
         System.out.println(str1);
         
         
	}

}
