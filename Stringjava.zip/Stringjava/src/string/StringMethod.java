package string;

public class StringMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str=new String("shaibaj");
		String str1=new String("Deshmukh");
	/*	
		System.out.println("CharAt() --->"+str.charAt(2));//CharAt --->a
		//It returns char value for the particular index
		
		System.out.println("codePointAt()-->"+str.codePointAt(2));//codePointAt-->97 
		//Return character asci value 
		 
		System.out.println("codePointBefore()-->"+str.codePointBefore(1));//codePointBefore()-->115
		//Returns the character (Unicode code point) before the specifiedindex
		//return before char char asci value return
		 
		System.out.println("codePointCount()--->"+str.codePointCount(0, 2));//codePointCount()--->2
		//char couunt start and ending
		
		System.out.println("compareTo()-->"+str.compareTo("shaibajj"));//compareTo()-->-1
		// compare two value same return 0,compare two value 1 value is big  return -1
	//compare two value 1 value is small  return 1
		
		
		str=str.concat(str1);
		System.out.println("concat()-->"+str);//run time execution memory stored heap Concatenates the specified string to the end of this string.
		System.out.println("concat()-->"+str.concat(str1));//concat()-->shaibajDeshmukh
		//combination of two string
		
		System.out.println("contains()-->"+str.contains("shai"));//true
		//Returns true if and only if this string contains the specifiedsequence of char values.
		if(str.contains("shai"))
		{
			System.out.println("yes");
		}
		else {
			System.out.println("no");
		}
		
		
		System.out.println("contentEquals()-->"+str.contentEquals(str1));//false
		//Compares this string to the specified CharSequence.  return true false
		 
		System.out.println("startsWith()-->"+str.startsWith("j"));//false
		System.out.println("endsWith()-->"str.endsWith("j"));//true
		//this string ends with the specified suffix.
		//return true or false
		
		String str3=new String("sh ibaj");
		System.out.println(str3.isEmpty());//false
		//Returns true if the string length is 0.
		
		System.out.println("length()-->"+str.length());//length()-->
		//Returns the length of the string.
		 // Convert to lowercase and uppercase
		
		 String lowercase = str.toLowerCase();
        String uppercase = str.toUpperCase();
        System.out.println("Lowercase: " + lowercase);
        System.out.println("Uppercase: " + uppercase);
        
        System.out.println("equal()-->"+str.equals(str1));//equal()-->false
	//compaires tthe value of string object return boolean value
	 
	   System.out.println("equalsIgnoreCase()-->"+str.equalsIgnoreCase(str1));//equalsIgnoreCase()-->false
    	//Compares this String to another String, ignoring case considerations.
        
       
		
		 // Substring
        String substring = str.substring(0,2); // starting from index 5 till end
        System.out.println("Substring from index 7: " + substring);//Substring from index 7: sh
        System.out.println("substring()-->"+str.substring(6));//j
        //	Returns a new string which is the substring of a specified string
        
     // Replace characters
        String replaced = str.replace('a', 'e');
        System.out.println("Replaced ()--> " + replaced);//Replaced ()--> sheibej
        //Returns a new string resulting from replacing all occurrences of oldChar in this string with newChar.
  	System.out.println("replaceAll()-->"+str.replaceAll(str, str1));//replaceAll()-->Deshmukh
		//Replaces each substring of this string that matches the given regular expression with the given replacement
		System.out.println("replaceFirst()-->"+str.replaceFirst(str, str1));//replaceFirst()-->Deshmukh
		//Replaces the first occurrence of a substring that matches the given regular expression with the given replacement
		
        System.out.println("contentEquals()-->"+str.contentEquals("shaibaj"));//contentEquals()-->true
      //return boolean value
      //Checks whether a string contains the exact same sequence of characters of the specified CharSequence or StringBuffer
	
      System.out.println("indexOf()-->"+str.indexOf('a'));//indexOf()-->2
	//Returns the index within the string of the first occurrence of the specified character.
	 
	 */
		System.out.println("isBlank()-->"+str.isBlank());//isBlank()-->false
		// Returns true if the string is empty or contains only whitespace characters.
		
		System.out.println("matches()-->"+str.matches(str1));//matches()-->false
		//Searches a string for a match against a regular expression, and returns the matches
		
	System.out.println("toString()-->"+str.toString());//toString()-->shaibaj
	//Returns the value of a String object
	
	System.out.println("getClass()-->"+str.getClass());//getClass()-->class java.lang.String
	//method is used to get the runtime class of an object. It returns a Class object that represents the runtime class of the object.
	System.out.println("getBytes()-->"+str.getBytes());//getBytes()-->[B@1e643faf
	//Encodes this String into a sequence of bytes using the named charset, storing the result into a new byte array
	/*
	 String equalsIgnoreCase()
String join()String split()
String notify(),notifyAll()
String toCharArray()String trim()
String valueOf()String intern()
String describeConstable()	,formatted(args),resolveConstantDesc(null)	
*/

	}

}
