/**
 * 
 */
/**
 * @author Shaibaj
 *
 */
module collectionFramework {
}