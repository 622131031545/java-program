package collectionFrameworkSorting;

public class Vehical implements Comparable<Vehical>{

	private String name;
    private double price;
	public Vehical(String name, double price) {
		
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public int compareTo(Vehical o) {
		// TODO Auto-generated method stub
		
/*if(this.price<o.getPrice())
			return -1;
			else if(this.price>o.getPrice())
				return 1;
			else
				return 0;*/
				
	return this.name.compareTo(name);
	}
}
