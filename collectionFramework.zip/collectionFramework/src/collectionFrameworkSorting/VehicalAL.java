package collectionFrameworkSorting;

import java.util.ArrayList;
import java.util.Collections;

public class VehicalAL {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Vehical> VehicalList=new ArrayList<>();
		Vehical v1=new Vehical("Car", 50000);
		
		Vehical v3=new Vehical("Truck", 70000);
		Vehical v4=new Vehical("Scooter", 1000);
		Vehical v2=new Vehical("Bike", 2000);
		VehicalList.add(v1);
		VehicalList.add(v2);
		VehicalList.add(v3);
		VehicalList.add(v4);
		 Collections.sort(VehicalList);
	        
	        System.out.println("\tVehical Name \tVehical Price ");
		for(Vehical v:VehicalList)
		{
			System.out.println("\t\t "+v.getName()+"\t\t "+v.getPrice());
		}
	}

}
