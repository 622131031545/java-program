package collectionFrameworkSorting;

public class Employee implements Comparable<Employee>{

private int EmployeeNo;
private String EmployeeName;
private String department;
private double sallary;
public Employee(int employeeNo, String employeeName, String department, double sallary) {

	EmployeeNo = employeeNo;
	EmployeeName = employeeName;
	this.department = department;
	this.sallary = sallary;
}
public int getEmployeeNo() {
	return EmployeeNo;
}
public void setEmployeeNo(int employeeNo) {
	EmployeeNo = employeeNo;
}
public String getEmployeeName() {
	return EmployeeName;
}
public void setEmployeeName(String employeeName) {
	EmployeeName = employeeName;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public double getSallary() {
	return sallary;
}
public void setSallary(double sallary) {
	this.sallary = sallary;
}
@Override
public int compareTo(Employee o) {
	// TODO Auto-generated method stub
	if(this.EmployeeNo<o.getEmployeeNo())
		return -1;
		else if(this.EmployeeNo>o.getEmployeeNo())
			return 1;
		else
			return 0;
}


}