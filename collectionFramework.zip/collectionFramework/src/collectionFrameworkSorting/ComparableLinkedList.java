package collectionFrameworkSorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class ComparableLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
LinkedList<Student> studList=new LinkedList<>();
        
        Student s1=new Student(10, "A", "B", "C", 56.78f);
        Student s2=new Student(1, "P", "Q", "R", 76.78f);
        Student s3=new Student(11, "L", "M", "N", 46.78f);
        Student s4=new Student(5, "X", "Y", "Z", 89.34f);
        Student s5=new Student(3, "P", "X", "Z", 56.78f);
        
        studList.add(s1);
        studList.add(s2);
        studList.add(s3);
        studList.add(s4);
        studList.add(s5);
          
        Collections.sort(studList);
        
        System.out.println("Roll Number\tFirst Name\tMiddle Name\tLast Name\tPercentage");
        
        for(Student s:studList) {
        	System.out.println(s.getrNo()+"\t\t"+s.getFname()+"\t\t"+s.getMname()+"\t\t"+s.getLname()+"\t\t"+s.getPercentage());  
        }

	}

}
