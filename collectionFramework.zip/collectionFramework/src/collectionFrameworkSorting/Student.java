package collectionFrameworkSorting;

public class Student implements Comparable<Student>{
	private int rNo;
	private String fname;
	private String mname;
	private String lname;
	private float percentage;
	
	public Student(int rNo,String fname,String mname,String lname,float percentage) {
		// TODO Auto-generated constructor stub
		this.fname=fname;
		this.lname=lname;
		this.mname=mname;
		this.percentage=percentage;
		this.rNo=rNo;
		
	}

	public int getrNo() {
		return rNo;
	}

	public void setrNo(int rNo) {
		this.rNo = rNo;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		/* sorting by percentage
		 * if(this.percentage<o.getPercentage())
		return -1;
		else if(this.percentage>o.getPercentage())
			return 1;
		else
			return 0;*/
		
		//sorting by rollnumber Decending Number
		if(this.rNo<o.getrNo())
			return -1;
			else if(this.rNo>o.getrNo())
				return 1;
			else
				return 0;
	}
	

}
