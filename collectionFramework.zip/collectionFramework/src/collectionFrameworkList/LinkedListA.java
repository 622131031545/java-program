package collectionFrameworkList;

import java.util.ArrayList;
import java.util.LinkedList;

public class LinkedListA {

	private static boolean add;
//offer
	public static void main(String[] args) {
		  LinkedList<String> pl = new LinkedList<>();
		  pl.add("Core Java");
		  pl.add("Html");
		  pl.add("Css");
		  pl.add("Javascript");
		  pl.add("Python");
		  pl.add("Cpp");
		  pl.add("Ruby");
		  pl.add("C#");

		  System.out.println("Computer Programming Languages List:"+pl);
		  //Computer Programming Languages List:[Core Java, Html, Css, Javascript, Python, Cpp, Ruby, C#]
		  LinkedList<String> pl1 = new LinkedList<>();

pl1.add("React");
pl1.add("Angular");
System.out.println("Computer Programming Languages List:"+pl1);
//Computer Programming Languages List:[React, Angular]
LinkedList<String> pl2=new LinkedList<>();
pl2.add("Java");
pl2.add("React");
pl2.add("Angular");
/*
pl.addAll(pl1);
System.out.println("Computer Programming Languages List:"+pl);
//Computer Programming Languages List:[Core Java, Html, Css, Javascript, Python, Cpp, Ruby, C#, React, Angular]
	
System.out.println(pl.clone());//[Core Java, Html, Css, Javascript, Python, Cpp, Ruby, C#, React, Angular]
//returns a copy of the ArrayList object


pl1.clear();
System.out.println(pl1);//[]
//The clear() method does not return any value. Rather, it makes changes to the arraylist.
 
System.out.println(pl.contains("sd"));//false
//returns true if the specified element is present in the arraylist.
//returns false if the specified element is not present in the arraylist.
System.out.println(pl.containsAll(pl1));//true

System.out.println(pl1.getClass());//class java.util.ArrayList
System.out.println(pl1.hashCode());//-1044993020
System.out.println(pl1.isEmpty());//false
//

int position = pl.indexOf("Core Java");
System.out.println("First Occurrence of Java: " + position);//First Occurrence of Java: 0
//returns the position of the specified element from the arraylist
//If the specified element doesn't exist in the list, the indexOf() method returns -1.
 

pl.remove("Python");
System.out.println("\nAfter removing Python:"+pl);
//After removing Python:[Core Java, Html, Css, Javascript, Cpp, Ruby, C#, React, Angular]
System.out.println("\nSize of the list: " + pl.size());//Size of the list: 9


System.out.println(pl.subList(0, 2));
//[Core Java, Html]
//return a portion of arraylist from the given arraylist
//fromIndex - the starting position from where elements are extracted
toIndex - the ending position up to which elements are extracted
pl.set(0, "C#");
System.out.println(pl);//[C#, Angular]
//The set() method takes two parameters.

index - position of the element to be replaced
element - new element that is to be stored at index
returns the element previously present at index

pl.trimToSize();
System.out.println("Size of ArrayList: " + pl.size());//Size of ArrayList: 10
//The trimToSize() method does not take any parameters
//The trimToSize() method does not return any value. Rather, it only changes the capacity of the arraylist.


// retain the common element
pl1.retainAll(pl2);
System.out.println("Common Elements: " + pl1);//Common Elements: [React, Angular]

System.out.println("String"+pl.toString());
//String[Core Java, Html, Css, Javascript, Python, Cpp, Ruby, C#, React, Angular]
//returns a string representation of the arraylist



pl1.addFirst("Android");
System.out.println(pl1);//[Android, React, Angular]
//// add a new element at first position
 
  pl1.addLast("Java");
System.out.println(pl1);//[Android,React, Angular, Java]
//// add a new element at last position

System.out.println(pl1.element());//React
//return first position element

System.out.println(pl1.get(0));//React
//returns the element present in the mentioned position in the linked list.

System.out.println(pl1.getFirst());//React
//returns the first element in this linked list. 

System.out.println(pl1.getLast());//Java
//returns the last element in this linked list. 

System.out.println(pl.getClass());//class java.util.LinkedList

pl1.offer("Java");
System.out.println(pl1);//[React, Angular, Java]
//put last position element
pl1.offerFirst("Sql");
System.out.println(pl1);//[Sql, React, Angular, Java]
// adds element at first.
pl1.offerLast("Python");
System.out.println(pl1);//[Sql, React, Angular, Java, Python]
//adds element at end.
 
 
 System.out.println(pl1);//[React, Angular]
System.out.println(pl1.peek());//React
//This method retrieves, but does not remove, the head (first element) of this list.
System.out.println(pl1.peekFirst());////React
// This method retrieves, but does not remove, the first element of this list, or returns null if this list is empty. This works similar to peek().
System.out.println(pl1.peekLast());//Angular
//This method retrieves, but does not remove, the last element of this list, or returns null if this list is empty.


System.out.println(pl1.poll());//React
//This method retrieves and removes the head (first element) of this list.
System.out.println(pl1.pollFirst());//Angular
//This method retrieves and removes the first element of this list, or returns null if this list is empty.
System.out.println(pl1.pollLast());//null
//This method retrieves and removes the last element of this list, or returns null if this list is empty.

 */
pl1.pop();
System.out.println(pl1);//[Angular]
//.pop() method is used to remove and return the top element from the stack represented by the LinkedList. 

pl1.push("React");
System.out.println(pl1);//[React, Angular]
//Pushing an element in the stack 

	}

}
