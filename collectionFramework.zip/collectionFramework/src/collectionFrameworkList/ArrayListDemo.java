package collectionFrameworkList;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* ArrayList list2=new ArrayList();  //non-generic arraylist
        list2.add(10);
        list2.add(33.4f);*/
		
        ArrayList<Integer> list1=new ArrayList<>();  //creates an empty list with size 10.Generic arraylist
        ArrayList<Integer> list2=new ArrayList<>(list1); // creates the list with exsiting arraylist
        ArrayList<Integer> list3=new ArrayList<>(5);  //creates an empty list with capacity 5
      
        list1.add(10);
        list1.add(20);
     //   list1.add(3.4f);  dosn't allowed as list1 is generic
        System.out.println("Array List elments are "+list1);
        list1.add(1, 15);
        System.out.println("Array List elments are "+list1);
        list1.add(20);
        
        /* list3.add(30);
       list3.add(40);
       
       list1.addAll(list3);
       System.out.println(list1);
       
       list1.addAll(0, list3);
       System.out.println(list1);
       
       list1.clear();
       System.out.println(list1);
       
       list1.clone();
       
       System.out.println(list1.contains(50));
       
       System.out.println(list1.containsAll(list3));
       
       System.out.println(list1.get(0));
       
       System.out.println(list1.getClass());
       System.out.println(list1.hashCode());
       
       System.out.println(list1.indexOf(15));
       
       System.out.println(list1.isEmpty());
      
       System.out.println(list1.lastIndexOf(20));*/
       
       list1.set(0, 5);
      //  list1.add(0,5);
       System.out.println(list1);
      
       
   
	}

}
