package collectionReferanceEntity;

import java.util.ArrayList;
import java.util.LinkedList;

import collectionFrameworkSorting.Employee;

public class EmpArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Employee> Employeelist=new ArrayList<>();
		Employee e1=new Employee(1,"Shaibaj","It",50000);
		Employee e2=new Employee(2,"Pranav","It",50000);
		Employee e3=new Employee(3,"Sagar","It",60000);
		Employee e4=new Employee(4,"Ajay","Developer",50000);
		Employee e5=new Employee(5,"Kishor","Hr",60000);
		Employeelist.add(e1);
		Employeelist.add(e2);
		Employeelist.add(e3);
		System.out.println("Emp ID \tEmp Name \tEmp Department \tEmp Sallary ");
		for(Employee e:Employeelist)
		{
			System.out.println("\t "+e.getEmployeeNo()+"\t "+e.getEmployeeName()+"\t "+e.getDepartment()+"\t "+e.getSallary());
		}

	}

}
