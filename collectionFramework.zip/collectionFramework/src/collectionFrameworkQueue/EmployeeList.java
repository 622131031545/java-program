package collectionFrameworkQueue;

import java.util.*;
import java.util.PriorityQueue;

class Employee{
	private int EmployeeNo;
	private String EmployeeName;
	private String department;
	private double sallary;
	public Employee(int employeeNo, String employeeName, String department, double sallary) {
	
		EmployeeNo = employeeNo;
		EmployeeName = employeeName;
		this.department = department;
		this.sallary = sallary;
	}
	public int getEmployeeNo() {
		return EmployeeNo;
	}
	public void setEmployeeNo(int employeeNo) {
		EmployeeNo = employeeNo;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public double getSallary() {
		return sallary;
	}
	public void setSallary(double sallary) {
		this.sallary = sallary;
	}
	
	
	
}
public class EmployeeList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 PriorityQueue<Employee> Employeelist = new PriorityQueue<>();
		
		Employee e1=new Employee(1,"Shaibaj","It",50000);
		Employee e2=new Employee(2,"Pranav","It",50000);
		Employee e3=new Employee(3,"Sagar","It",60000);
		Employeelist.add(e1);
		Employeelist.add(e2);
		Employeelist.add(e3);
		Employeelist.add(e3);
		for(Employee e:Employeelist)
		{
			System.out.println("Employee ID "+e.getEmployeeNo()+"\nEmployee Name "+e.getEmployeeName()+"\nEmployee Department "+e.getDepartment()+"\nEmployee Sallary "+e.getSallary());
		}
		
	}

}
