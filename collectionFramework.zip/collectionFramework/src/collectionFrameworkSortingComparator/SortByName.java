package collectionFrameworkSortingComparator;

import java.util.Comparator;

public class SortByName implements Comparator<Vhehical>{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compare(Vhehical o1, Vhehical o2) {
		// TODO Auto-generated method stub
		return o1.name.compareTo(o2.name);
	}

}
