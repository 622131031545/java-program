package collectionFrameworkSortingComparator;

import java.util.Comparator;

public class SortByProductSupplierName implements Comparator<Product> {

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		return o1.supplierName.compareTo(o2.getSupplierName());
	}

}
