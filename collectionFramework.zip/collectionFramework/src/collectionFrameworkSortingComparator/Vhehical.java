package collectionFrameworkSortingComparator;

import java.util.ArrayList;
import java.util.Collections;

//import collectionFrameworkSorting.Vhehical;

public class Vhehical {
	 String name;
	 double price;
	public Vhehical(String name, double price) {
		
		this.name = name;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Vhehical> VhehicalList=new ArrayList<>();
		Vhehical v1=new Vhehical("Car", 50000);
		Vhehical v2=new Vhehical("Bike", 2000);
		Vhehical v3=new Vhehical("Truck", 70000);
		Vhehical v4=new Vhehical("Scooter", 1000);
		
		VhehicalList.add(v1);
		VhehicalList.add(v2);
		VhehicalList.add(v3);
		VhehicalList.add(v4);
		 Collections.sort(VhehicalList,new SortByPrice());
	        
	        System.out.println("Sorting By Price \n\tVhehical Name \tVhehical Price ");
		for(Vhehical v:VhehicalList)
		{
			System.out.println("\t\t "+v.getName()+"\t\t "+v.getPrice());
		}
		
		 Collections.sort(VhehicalList,new SortByName());
	        
	        System.out.println("\nSorting By Name\n \tVhehical Name \tVhehical Price ");
		for(Vhehical v:VhehicalList)
		{
			System.out.println("\t\t "+v.getName()+"\t\t "+v.getPrice());
		}
	}
}
