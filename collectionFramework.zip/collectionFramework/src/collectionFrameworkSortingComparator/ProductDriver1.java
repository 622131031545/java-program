package collectionFrameworkSortingComparator;

import java.util.ArrayList;
import java.util.Collections;

public class ProductDriver1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Product> ProductList=new ArrayList<>();
		Product p1=new Product(1, "Laptop", 10, 1000.0, "Ajay");
		Product p2=new Product(2, "Phone", 20, 500.0, "Vijay");
		Product p3=new Product(3, "Tablet", 15, 800.0, "Rohit");
		Product p4=new Product(4, "Phone", 15, 1800.0, "Pranav");
		Product p5=new Product(5, "Laptop", 11, 1000.0, "Rahul");
		ProductList.add(p1);
		ProductList.add(p2);
		ProductList.add(p3);
		ProductList.add(p4);
		ProductList.add(p5);
		Collections.sort(ProductList,new SortByProductId());
		System.out.println("\nProduct Sort By Id \nProduct Id \t Product Name \t Product Count \t Product Price \t Product Supplier name" );
		for(Product p:ProductList)
			System.out.println(p.getProductId()+"\t\t"+p.getName()+"\t\t"+p.getCount()+"\t\t"+p.getPrice()+"\t\t"+p.getSupplierName());
		
		Collections.sort(ProductList,new SortByProductName());
		System.out.println("\nProduct Sort By Name \nProduct Id \t Product Name \t Product Count \t Product Price \t Product Supplier name" );
		for(Product p:ProductList)
			System.out.println(p.getProductId()+"\t\t"+p.getName()+"\t\t"+p.getCount()+"\t\t"+p.getPrice()+"\t\t"+p.getSupplierName());
		
		Collections.sort(ProductList,new SortByProductCount());
		System.out.println("\nProduct Sort By Count \nProduct Id \t Product Name \t Product Count \t Product Price \t Product Supplier name" );
		for(Product p:ProductList)
			System.out.println(p.getProductId()+"\t\t"+p.getName()+"\t\t"+p.getCount()+"\t\t"+p.getPrice()+"\t\t"+p.getSupplierName());
		
		
		Collections.sort(ProductList,new SortByProductPrice());
		System.out.println("\nProduct Sort By Price \nProduct Id \t Product Name \t Product Count \t Product Price \t Product Supplier name" );
	for(Product p:ProductList)
		System.out.println(p.getProductId()+"\t\t"+p.getName()+"\t\t"+p.getCount()+"\t\t"+p.getPrice()+"\t\t"+p.getSupplierName());
	Collections.sort(ProductList,new SortByProductSupplierName());
	System.out.println("\nProduct Sort By Supplier Name \nProduct Id \t Product Name \t Product Count \t Product Price \t Product Supplier name" );
	for(Product p:ProductList)
		System.out.println(p.getProductId()+"\t\t"+p.getName()+"\t\t"+p.getCount()+"\t\t"+p.getPrice()+"\t\t"+p.getSupplierName());
	
	}

}
