package collectionFrameworkSortingComparator;

import java.util.ArrayList;

public class Product {
	int productId;
    String name;
    int count;
    double price;
    String supplierName;
	public Product(int productId, String name, int count, double price, String supplierName) {
		super();
		this.productId = productId;
		this.name = name;
		this.count = count;
		this.price = price;
		this.supplierName = supplierName;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	

	

}
