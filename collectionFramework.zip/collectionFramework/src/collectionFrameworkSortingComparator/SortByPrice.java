package collectionFrameworkSortingComparator;

import java.util.Comparator;

public class SortByPrice implements Comparator<Vhehical>{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compare(Vhehical o1, Vhehical o2) {
		// TODO Auto-generated method stub
		if(o1.price<o2.getPrice())
			return -1;
		else if(o1.price>o2.getPrice())
			return 1;
		else
			return 0;
	}

}
