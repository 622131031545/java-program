package collectionFrameworkSortingComparator;

import java.util.Comparator;

public class SortByProductName implements Comparator<Product> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		return o1.name.compareTo(o2.name);
	}

}
