package collectionFrameworkSortingComparator;

import java.util.Comparator;

public class SortByProductCount implements Comparator<Product> {

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		if(o1.count<o2.getCount())
			return -1;
		else if(o1.count>o2.getCount())
			return 1;
		else
			return 0;
	}

}
