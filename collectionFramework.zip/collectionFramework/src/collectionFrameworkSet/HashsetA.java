package collectionFrameworkSet;

import java.util.HashSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class HashsetA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSet<String> pl=new HashSet<>();
		 pl.add("Core Java");
		  pl.add("Html");
		  pl.add("Css");
		  pl.add("Javascript");
		  pl.add("Python");
		  pl.add("Cpp");
		  pl.add("Ruby");
		  pl.add("C#");

		  System.out.println("Computer Programming Languages List:"+pl);
		  //Computer Programming Languages List:[C#, Core Java, Cpp, Css, Html, Javascript, Python, Ruby]
		  HashSet<String> pl1 = new HashSet<>();

		  pl1.add("React");
		  pl1.add("Angular");
		  System.out.println("Computer Programming Languages List:"+pl1);
		  //Computer Programming Languages List:[React, Angular]
		  HashSet<String> pl2=new HashSet<>();
		  pl2.add("Java");
		  pl2.add("React");
		  pl2.add("Angular");
		  
		  pl1.addAll(pl2);
		  System.out.println(pl1);//[Angular, Java, React]
		  //Adds all of the elements in the specified collection to the set.
		  
		  
		  System.out.println(pl.clone());//[C#, Core Java, Cpp, Css, Html, Javascript, Python, Ruby]
		//returns a copy of the ArrayList object


		pl1.clear();
		System.out.println(pl1);//[]
		//The clear() method does not return any value. Rather, it makes changes to the arraylist.
		 
		  System.out.println(pl.contains("sd"));//false
		//returns true if the specified element is present in the arraylist.
		//returns false if the specified element is not present in the arraylist.
		
		  System.out.println(pl.containsAll(pl1));//false
		  //eturns true if the arraylist contains all elements of collection

		System.out.println(pl1.getClass());//class java.util.TreeSet
		//returns the runtime class of an object. 
		
		System.out.println(pl1.hashCode());//884952865
		//returns a hash code value for the object. 
		
		System.out.println(pl1.isEmpty());//false
		//returns true if the arraylist does not contain any elements
		//returns false if the arraylist contains some elements
		
		  pl.remove("Python");
		  System.out.println("\nAfter removing Python:"+pl);
		  //After removing Python:[C#, Core Java, Cpp, Css, Html, Javascript, Ruby]
		  
		  System.out.println("\nSize of the list: " + pl.size());//Size of the list: 7

 		//retain the common element
		  pl1.retainAll(pl2);
		  System.out.println("Common Elements: " + pl1);//Common Elements: [Angular, React]

		  System.out.println("String"+pl.toString());
		  //String[C#, Core Java, Cpp, Css, Html, Javascript, Python, Ruby]
		  //returns a string representation of the arraylist
		
		 
			Object[] array =  pl2.toArray();
			System.out.println(array);//[Ljava.lang.Object;@3f3afe78
			for(int ind=0;ind<array.length;ind++)
			System.out.println(array[ind]);//Angular	Java	React
			//toArray() method in Java is used to convert a collection into an array. 


	}

}
