package collectionFrameworkSet;

import java.util.PriorityQueue;
import java.util.*;
import java.util.TreeSet;

public class TreeSetAssignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String> pl=new TreeSet<>();
		TreeSet<String> set2=new TreeSet<>(pl);
		 pl.add("Core Java");
		  pl.add("Html");
		  pl.add("Css");
		  pl.add("javascript");
		  pl.add("Python");
		  pl.add("Cpp");
		  pl.add("Ruby");
		  pl.add("C#");
		System.out.println(pl);
		System.out.println(pl.higher("Internet"));
			//System.out.println(pl.headSet("Css"));//[C#, Core Java, Cpp]
			//System.out.println(pl.tailSet("Css"));
			//System.out.println(pl.subSet("Cpp", "Python"));
			//It returns the group of elements that are less than the specified element.
		 // System.out.println(pl.floor("Css"));//React

		 // System.out.println(pl.higher("Html"));//
			//// Finding the least element strictly greater than the given element
			
		/*  System.out.println("Computer Programming Languages List:"+pl);
		  //Computer Programming Languages List:[C#, Core Java, Cpp, Css, Html, Javascript, Python, Ruby]
		  TreeSet<String> pl1 = new TreeSet<>();

		  pl1.add("React");
		  pl1.add("Angular");
		  System.out.println("Computer Programming Languages List:"+pl1);
		  //Computer Programming Languages List:[React, Angular]
		  TreeSet<String> pl2=new TreeSet<>();
		  pl2.add("Java");
		  pl2.add("React");
		  pl2.add("Angular");
		  
		  pl1.addAll(pl2);
		  System.out.println(pl1);//[Angular, Java, React]
		  //Adds all of the elements in the specified collection to the set.
		 
		  
		  System.out.println( pl.ceiling("C"));//C#
		  //// Finding the least element greater than or equal to a given element
		  
		  System.out.println(pl.clone());//[C#, Core Java, Cpp, Css, Html, Javascript, Python, Ruby]
		//returns a copy of the ArrayList object


		pl1.clear();
		System.out.println(pl1);//[]
		//The clear() method does not return any value. Rather, it makes changes to the arraylist.
		 
		  System.out.println(pl.contains("sd"));//false
		//returns true if the specified element is present in the arraylist.
		//returns false if the specified element is not present in the arraylist.
		
		  System.out.println(pl.containsAll(pl1));//false
		  //eturns true if the arraylist contains all elements of collection

		System.out.println(pl1.getClass());//class java.util.TreeSet
		//returns the runtime class of an object. 
		
		System.out.println(pl1.hashCode());//884952865
		//returns a hash code value for the object. 
		
		System.out.println(pl1.isEmpty());//false
		//returns true if the arraylist does not contain any elements
		//returns false if the arraylist contains some elements
		
		  pl.remove("Python");
		  System.out.println("\nAfter removing Python:"+pl);
		  //After removing Python:[C#, Core Java, Cpp, Css, Html, Javascript, Ruby]
		  
		  System.out.println("\nSize of the list: " + pl.size());//Size of the list: 7

 		//retain the common element
		  pl1.retainAll(pl2);
		  System.out.println("Common Elements: " + pl1);//Common Elements: [Angular, React]

		  System.out.println("String"+pl.toString());
		  //String[C#, Core Java, Cpp, Css, Html, Javascript, Python, Ruby]
		  //returns a string representation of the arraylist
		
		System.out.println(pl.first());//C#
		//This method will return the first element in TreeSet
		pl1.floor("java");
		
		System.out.println(pl1.floor("React"));//React
		//// Finding the greatest element less than or equal to the given element
		 //return  nearest element small or greater

		 
	System.out.println(pl.higher("React"));//Ruby
	//// Finding the least element strictly greater than the given element
	
	 // pollFirst(): Remove and return the first element
    String firstElement = pl1.pollFirst();
    System.out.println("Removed first element: " + firstElement);//Removed first element: Angular
//This method retrieves and removes the first (lowest) element of the set, or returns null if the set is empty.
    
    // pollLast(): Remove and return the last element
    String lastElement = pl1.pollLast();
    System.out.println("Removed last element: " + lastElement);//Removed last element: React
//This method retrieves and removes the last (highest) element of the set, or returns null if the set is empty.

    // lower(E e): Retrieve the greatest element less than a given element
    String lowerElement = pl.lower("Cpp");
    System.out.println("Greatest element less than 'Cpp': " + lowerElement);//Greatest element less than 'Cpp': Core Java
	//This method returns the greatest element in the set strictly less than the given element null if there is no such element.

		 


		
	// Retrieve the last element
    String lastElement = pl.last();

    // Print the last element
    System.out.println("Last element: " + lastElement);
	
	Object[] array =  pl2.toArray();
	System.out.println(array);//[Ljava.lang.Object;@3f3afe78
	for(int ind=0;ind<array.length;ind++)
	System.out.println(array[ind]);//Angular	Java	React
	//toArray() method in Java is used to convert a collection into an array. 

	//headSet,stream(),spliterator(),subSet(lastElement, lastElement),descendingSet(),higher()
	
	*/
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	SortedSet<String> headSet = pl.headSet("css");
	System.out.println(headSet);//[C#, Core Java, Cpp, Css, Html, Javascript, Python, Ruby]
	System.out.println(pl.headSet("Css"));//[C#, Core Java, Cpp]
	//It returns the group of elements that are less than the specified element.
	*/
	}

}
